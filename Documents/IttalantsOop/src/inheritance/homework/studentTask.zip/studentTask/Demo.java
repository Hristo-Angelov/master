package inheritance.homework.studentTask;

public class Demo {

	public static void main(String[] args) {
		
		
		ArrayOfPersons array = new ArrayOfPersons();
		array.printInfo();
		System.out.println("**********");
		array.priceForOvertimeLabour();
	}

}
